import 'package:flutter/material.dart';
import 'package:foundactionsf/Component/button.dart';
import 'package:foundactionsf/Background_logsin/Background.dart';
import 'package:foundactionsf/Component/textfiled.dart';
import 'package:foundactionsf/Authorization/signup.dart';
import 'package:foundactionsf/Screens/home.dart';
import 'package:foundactionsf/firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController usrName = TextEditingController();
  final TextEditingController password = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool isLoading = false; // Loading state for login button
  bool isLoginError = false; // To show login error messages

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> loginUser() async {
    setState(() {
      isLoading = true;
      isLoginError = false;
    });

    try {
      await _auth.signInWithEmailAndPassword(
        email: usrName.text.trim(),
        password: password.text.trim(),
      );
      // Navigate to Home on successful login
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Home()),
      );
    } catch (e) {
      // Show error message if login fails
      setState(() {
        isLoginError = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      image: "user.png", // Pass the correct image for login
      child: Form(
        key: formKey,
        child: Column(
          children: [
            header(),
            body(),
            message(),
          ],
        ),
      ),
    );
  }

  Widget header() {
    return const ListTile(
      title: Text(
        "Welcome",
        style: TextStyle(
          fontSize: 54, // Bigger font size
          fontWeight: FontWeight.bold, // Bold font weight
        ),
        textAlign: TextAlign.center, // Center the text
      ),
      subtitle: Text("     Enter Your Credentials to access your account"),
    );
  }

  Widget body() {
    return Expanded(
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              InputField(
                validator: (value) {
                  if (value.isEmpty) {
                    return "Email is required";
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                    return "Enter a valid email";
                  }
                  return null;
                },
                hintText: "Email",
                icon: Icons.email,
                controller: usrName,
              ),
              InputField(
                trailing: const Icon(Icons.visibility_off),
                validator: (value) {
                  if (value.isEmpty) {
                    return "Password is required";
                  }
                  if (value.length < 6) {
                    return "Password must be at least 6 characters";
                  }
                  return null;
                },
                hintText: "Password",
                icon: Icons.lock,
                controller: password,
              ),
              Button(
                label: isLoading ? "Logging in..." : "Login",
                press: () {
                  if (formKey.currentState!.validate()) {
                    loginUser();
                  }
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't have an account?"),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const SignUp()),
                      );
                    },
                    child: const Text("Register"),
                  ),
                ],
              ),
              TextButton(
                onPressed: () {
                  // Add "Forgot Password" functionality here if needed
                },
                child: const Text("Forgot Password"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget message() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Column(
        children: [
          isLoginError
              ? Text(
                  "Login failed. Please check your email and password.",
                  style: TextStyle(color: Colors.red.shade900),
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}
