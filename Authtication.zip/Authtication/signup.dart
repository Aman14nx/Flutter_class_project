import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Import Firebase Authentication
import 'package:foundactionsf/Component/button.dart';
import 'package:foundactionsf/Background_logsin/Background.dart';
import 'package:foundactionsf/Component/textfiled.dart';
import 'package:foundactionsf/Authorization/login.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final usrName = TextEditingController();
  final password = TextEditingController();
  final fullname = TextEditingController();
  final email = TextEditingController();
  final confirmPassword = TextEditingController();

  bool isValidated = false;
  bool isLoading = false; // Loading state for the registration process
  final formKey = GlobalKey<FormState>();

  final FirebaseAuth _auth = FirebaseAuth.instance; // FirebaseAuth instance

  Future<void> register() async {
    setState(() {
      isLoading = true;
      isValidated = false;
    });

    try {
      // Register the user using Firebase Authentication
      await _auth.createUserWithEmailAndPassword(
        email: email.text.trim(),
        password: password.text.trim(),
      );

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Registration Successful")),
      );

      // Navigate to the Login screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Login()),
      );
    } catch (e) {
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      image: "sign.png", // Pass the correct image for signup
      height: .75, // Adjust height if needed
      child: Form(
        key: formKey,
        child: Column(
          children: [
            header(),
            body(),
            message(),
          ],
        ),
      ),
    );
  }

// Header
  Widget header() {
    return const Center(
      child: Text(
        "Register",
        style: TextStyle(
          fontSize: 32, // Increase the font size
          // fontWeight: FontWeight.bold, // Make the text bold
        ),
        textAlign: TextAlign.center, // Center the text horizontally
      ),
    );
  }

  Widget body() {
    // Typing box
    return Expanded(
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              InputField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return "Full Name is required";
                    }
                    return null;
                  },
                  hintText: "Full Name",
                  icon: Icons.person,
                  controller: fullname),
              InputField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return "Email is required";
                    } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+')
                        .hasMatch(value)) {
                      return "Enter a valid email address";
                    }
                    return null;
                  },
                  hintText: "Email Address",
                  icon: Icons.email,
                  controller: email),
              InputField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return "Username is required";
                    }
                    return null;
                  },
                  hintText: "Username",
                  icon: Icons.account_circle_rounded,
                  controller: usrName),
              InputField(
                  trailing: const Icon(Icons.visibility_off),
                  validator: (value) {
                    if (value.isEmpty) {
                      return "Password is required";
                    } else if (value.length < 6) {
                      return "Password must be at least 6 characters";
                    }
                    return null;
                  },
                  hintText: "Password",
                  icon: Icons.lock,
                  controller: password),
              InputField(
                  trailing: const Icon(Icons.visibility_off),
                  validator: (value) {
                    if (value.isEmpty) {
                      return "Re-Password is required";
                    } else if (password.text != confirmPassword.text) {
                      return "Passwords don't match";
                    }
                    return null;
                  },
                  hintText: "Re-enter password",
                  icon: Icons.lock,
                  controller: confirmPassword),

              // Button
              Button(
                  label: isLoading ? "Registering..." : "Register",
                  press: () {
                    if (formKey.currentState!.validate()) {
                      register();
                    } else {
                      setState(() {
                        isValidated = true;
                      });
                    }
                  }),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Already have an account"),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Login()));
                      },
                      child: const Text("Login")),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget message() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Column(
        children: [
          isValidated
              ? Text(
                  "Form is not Validated, Check above",
                  style: TextStyle(color: Colors.red.shade900),
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}
